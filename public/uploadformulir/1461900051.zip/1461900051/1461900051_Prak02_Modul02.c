#include<stdio.h>
int enkripsi (int angka, int decimal){
    int byte1, byte2, byte3, byte4;
    byte1 = (angka ^ decimal) &0x000000FF;
    byte2 = (((angka>>8) ^ decimal)<<8) &0x0000FF00;
    byte3 = (((angka>>16) ^ decimal)<<16) &0x0000FF00;
    byte4 = (((angka>>24) ^ decimal)<<24) &0xFF000000;
return (byte1+byte2+byte3+byte4);

}
