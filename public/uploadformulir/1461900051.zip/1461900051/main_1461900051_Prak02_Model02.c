#include <stdio.h>

int enkripsi(int angka, int decimal);
int main(){
    int angka,bil;
    printf("Masukan Angka 1-9 = ");
    scanf("%d", & angka);
    printf("Maukan 85 = ");
    scanf("%d", &bil);
    bil = bil &0x000000FF;
    printf("Hasil = ");
    printf("%d\n", enkripsi(angka, bil));
}
