#include <stdio.h>
#include <stdlib.h>

int main(){
    int desimal, angka1, angka2, hasil, i, j=0, k=0, a[8], b[8], c[8];

    printf("Masukan angka pertama : ");
    scanf("%d", &angka1);
    printf("Masukan angka kedua : ");
    scanf("%d", &angka2);
    hasil = angka1 + angka2;
    desimal = hasil;

    for(i=0; i<8; i++){
        a[i]= angka1%2;
        b[i]= angka2%2;
        c[i]= hasil%2;
        angka1 = angka1/2;
        angka2 = angka2/2;
        hasil = hasil/2;
        if(angka1==0){
            a[i+1]=0;
        }
        if(angka2==0){
            b[i+1]=0;
        }
        if(hasil==0){
            c[i+1]=0;
        }
        j++;
        k++;
    }
    printf("\nhasil \n");

    for(i=i-1;i>=0;i--){
        printf("%d", a[i]);
    }
    printf(" + ");

    for (j=j-1;j>=0;j--){
        printf("%d", b[j]);
    }
    printf(" = ");

    for (k=k-1;k>=0;k--){
        printf("%d", c[k]);
    }
    printf("\ndesimal : %d", desimal);
    return 0;
}